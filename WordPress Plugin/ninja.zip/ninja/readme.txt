This plugin take data of Cakes and display on page which contain shortcode. 
Also it allow to add cake from admin page "Cake".


Steps to setup this plugin.

1. Active the plugin
2. Add shortcode [cakelist] to a page where you want to list all cakes
3. Cake list can be filter with category i.e. [cakelist cat=categoryname]
4. Add cake from admin menu "Cake".
5. Reset permalink.